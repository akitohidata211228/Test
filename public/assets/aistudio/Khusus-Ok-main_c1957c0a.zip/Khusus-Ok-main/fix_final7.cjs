const fs = require('fs');
let lines = fs.readFileSync('api/index.ts', 'utf-8').split('\n');

// Restore 1652 to `    });`
lines[1652] = "    });";

// Delete 1653 and 1654 (which are now at 1653 and 1654? Wait, earlier I spliced line 1652!)
// Let's just find the exact block and replace it.
let content = lines.join('\n');
content = content.replace(/isFallback: true\n  \}\n\}\)\;\n\n\/\/ Threads Proxy/g, 'isFallback: true\n    });\n  }\n});\n\n// Threads Proxy');
fs.writeFileSync('api/index.ts', content);
