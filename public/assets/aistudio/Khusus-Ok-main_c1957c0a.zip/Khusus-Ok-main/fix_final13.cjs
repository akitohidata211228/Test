const fs = require('fs');
let content = fs.readFileSync('api/index.ts', 'utf-8');
content += '\n}\n}\n}\n';
fs.writeFileSync('api/index.ts', content);
