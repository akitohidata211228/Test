const fs = require('fs');
let code = fs.readFileSync('api/index.ts', 'utf8');

// 1. Extract the original Cuki and Nanzz block from the instagram endpoint
const igStart = code.indexOf('// 1. Cuki API', code.indexOf('/api/proxy/instagram'));
const igEnd = code.indexOf('return res.status(500)', igStart);
const cukiNanzzBlock = code.substring(igStart - 6, igEnd); 

// 2. Fix the TikTok endpoint (remove lovethreads, restore cuki/nanzz)
const tiktokLoveStart = code.indexOf('// 1. LoveThreads Scraper');
const tiktokLoveEnd = code.indexOf('return res.status(500)', tiktokLoveStart);
if (tiktokLoveStart !== -1 && tiktokLoveEnd !== -1) {
    code = code.substring(0, tiktokLoveStart - 6) + cukiNanzzBlock + code.substring(tiktokLoveEnd);
}

// 3. Replace the Threads endpoint fallback with lovethreads
const threadsStart = code.indexOf('// 1. Cuki API', code.indexOf('/api/proxy/threads'));
const threadsEnd = code.indexOf('return res.status(500)', threadsStart);

const lovethreadsBlock = `      // 1. LoveThreads Scraper (Most Reliable for Threads)
      const endpoint = "https://lovethreads.net/api/ajaxSearch";
      const form = new URLSearchParams({
        q: url as string,
        t: "media",
        lang: "en",
      });
      const loveRes = await axios.post(endpoint, form.toString(), {
        headers: {
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          origin: "https://lovethreads.net",
          referer: "https://lovethreads.net/en",
          "x-requested-with": "XMLHttpRequest",
        },
      });
      const loveData = loveRes.data;
      
      if (loveData && loveData.status === "ok" && loveData.data) {
        console.log(\`[threads Proxy] lovethreads fallback success\`);
        const $ = cheerio.load(loveData.data);
        const images: any[] = [];
        const videos: any[] = [];
        
        $(".download-box > li").each((index, li) => {
          const item = $(li);
          if (item.find(".icon-dlimage").length) {
            const thumbnail = item.find(".download-items__thumb img").attr("src");
            const photoUrl = item.find('a[title="Download Photo"]').attr("href") || item.find('a:contains("Download Photo")').attr("href") || item.find('a.download-items__btn').attr("href");
            if (photoUrl) {
              images.push({ url: photoUrl, thumbnail });
            }
          }
          if (item.find(".icon-dlvideo").length) {
            const thumbnail = item.find(".download-items__thumb img").attr("src");
            const videoUrl = item.find('a[title="Download Video"]').attr("href") || item.find('a.download-items__btn').attr("href");
            if (videoUrl) {
              videos.push({ url: videoUrl, thumbnail, quality: "Video MP4" });
            }
          }
        });
        
        let mainVid = videos[0]?.url || "";
        let finalAud = mainVid ? \`/api/proxy/convert-audio?url=\${encodeURIComponent(mainVid)}\` : "";
        let mainThumb = videos[0]?.thumbnail || images[0]?.thumbnail || "";
        
        if (videos.length > 0 || images.length > 0) {
           return res.json({
            status: true,
            title: "Threads Post",
            thumbnail: mainThumb,
            video: mainVid,
            audio: finalAud,
            music: finalAud,
            mp3: finalAud,
            downloads: videos,
            images: images,
            isFallback: true
          });
        }
      } else if (loveData && loveData.mess && loveData.mess.toLowerCase().includes("private")) {
         return res.status(403).json({ error: "Postingan ini bersifat Private. Tidak dapat mendownload media dari akun private." });
      } else if (loveData && loveData.mess && loveData.mess.toLowerCase().includes("not found")) {
         return res.status(404).json({ error: "Postingan Threads tidak ditemukan atau URL salah." });
      }
    } catch (fallbackError: any) {
      console.log(\`[threads Proxy] lovethreads fallback failed:\`, fallbackError.message);
    }
    
    try {
`;

if (threadsStart !== -1 && threadsEnd !== -1) {
    code = code.substring(0, threadsStart - 6) + lovethreadsBlock + code.substring(threadsStart - 6, threadsEnd);
}

fs.writeFileSync('api/index.ts', code);
console.log("Fixed api/index.ts");
