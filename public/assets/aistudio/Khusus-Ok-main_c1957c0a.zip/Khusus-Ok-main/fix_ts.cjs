const fs = require('fs');
let code = fs.readFileSync('api/index.ts', 'utf-8');

// Replace await scrapeTikTok(url); with await scrapeTikTok(url as string);
code = code.replace(/await scrapeTikTok\(url\);/g, 'await scrapeTikTok(url as string);');
code = code.replace(/await scrapeInstagram\(url\);/g, 'await scrapeInstagram(url as string);');
code = code.replace(/await scrapeThreads\(url\);/g, 'await scrapeThreads(url as string);');
code = code.replace(/await seekin\.download\(url\);/g, 'await seekin.download(url as string);');

// fix AxiosHeaders typing issues
code = code.replace(/const contentType = response\.headers\["content-type"\];/g, 'const contentType = response.headers["content-type"] as string;');
code = code.replace(/const contentLength = response\.headers\["content-length"\];/g, 'const contentLength = response.headers["content-length"] as string;');

fs.writeFileSync('api/index.ts', code);
