const fs = require('fs');
let content = fs.readFileSync('api/index.ts', 'utf-8');
content = content.replace(/isFallback:\s*true\s*\}\}\);\/\//g, 'isFallback: true\n    });\n  }\n});\n\/\/');
content = content.replace(/isFallback:\s*true\s*\}\}\)\;/g, 'isFallback: true\n    });\n  }\n});\n');
fs.writeFileSync('api/index.ts', content);
