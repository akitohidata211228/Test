import axios from "axios";
import crypto from "crypto";

export interface SeekinFormat {
  quality: string;
  url: string;
  fileSize: number | null;
  ext: string;
}

export interface SeekinImage {
  url: string;
  format: string;
}

export interface SeekinResult {
  title: string;
  thumbnail: string;
  duration: number | null;
  formats: SeekinFormat[];
  images: SeekinImage[];
}

export class SeekinScraper {
  private baseUrl: string;
  private secretKey: string;
  private lang: string;

  constructor() {
    this.baseUrl = "https://api.seekin.ai";
    this.secretKey = "3HT8hjE79L";
    this.lang = "en";
  }

  private getHeaders(extra: Record<string, string> = {}): Record<string, string> {
    return {
      "accept": "*/*",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      "content-type": "application/json",
      "origin": "https://www.seekin.ai",
      "referer": "https://www.seekin.ai/",
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
      "sec-ch-ua": `"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"`,
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": `"Windows"`,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-site",
      ...extra
    };
  }

  private sortAndStringify(params: Record<string, any> = {}): string {
    if (!params || typeof params !== "object") return "";
    return Object.keys(params)
      .sort()
      .map(k => `${k}=${params[k]}`)
      .join("&");
  }

  private generateSign(timestamp: string, params: Record<string, any> = {}): string {
    const sortedStr = this.sortAndStringify(params);
    const raw = `${this.lang}${timestamp}${this.secretKey}${sortedStr}`;
    return crypto.createHash("sha256").update(raw).digest("hex");
  }

  private formatResult(data: any): SeekinResult {
    return {
      title: data.title || "",
      thumbnail: data.imageUrl || "",
      duration: data.duration || null,
      formats: (data.medias || [])
        .filter((m: any) => m.url)
        .map((m: any) => ({
          quality: m.format || (m.url.includes('.mp3') || m.url.includes('.m4a') ? 'audio' : 'video'),
          url: m.url,
          fileSize: m.fileSize || null,
          ext: m.format?.match(/\[\.(\w+)\]/)?.[1] || "mp4"
        })),
      images: (data.images || [])
        .filter((i: any) => i.url)
        .map((i: any) => ({
          url: i.url,
          format: i.format || "jpg"
        }))
    };
  }

  public async download(videoUrl: string): Promise<SeekinResult> {
    const timestamp = Date.now().toString();
    const params = { url: videoUrl.trim() };
    const sign = this.generateSign(timestamp, params);

    const res = await axios.post(
      `${this.baseUrl}/ikool/media/download`,
      { url: videoUrl.trim() },
      {
        timeout: 30000,
        headers: this.getHeaders({
          lang: this.lang,
          timestamp: timestamp,
          sign: sign
        })
      }
    );

    if (res.data.code !== "0000" || !res.data.data) {
      // console.log("Seekin API response:", JSON.stringify(res.data));
      throw new Error(`Seekin error: ${res.data.msg || "Unknown error"}`);
    }

    return this.formatResult(res.data.data);
  }
}
