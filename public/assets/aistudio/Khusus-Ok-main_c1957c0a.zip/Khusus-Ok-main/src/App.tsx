import { useState, useEffect, useRef, Component, ErrorInfo, ReactNode } from 'react';
import { Moon, Sun, Instagram, Youtube, Music2, Download, Loader2, ExternalLink, Facebook, Video, Clapperboard, ChevronLeft, ChevronRight, Play, Pause, Heart, Twitter, Tv, Film, Eye, AtSign, Zap, Ban, ShieldCheck, Smartphone, ChevronDown, ChevronUp, ClipboardPaste } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  props: ErrorBoundaryProps;

  public state: ErrorBoundaryState = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error caught by ErrorBoundary:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-zinc-100 dark:bg-zinc-900 transition-colors duration-500">
          <div className="neo-card w-full max-w-md p-8 text-center border-4 border-black bg-red-50 text-black shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-5 items-center justify-center font-sans">
            <div className="w-16 h-16 bg-red-500 rounded-full border-4 border-black flex items-center justify-center text-white text-3xl font-black shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
              !
            </div>
            <div>
              <h3 className="font-display font-black text-xl uppercase tracking-tight text-red-600">APLIKASI CRASH</h3>
              <p className="text-xs font-bold opacity-75 mt-2 font-mono bg-white/60 p-3 rounded border-2 border-black max-w-xs mx-auto overflow-x-auto text-left whitespace-pre-wrap">
                {this.state.error?.message ? String(this.state.error.message) : "Render Error"}
              </p>
            </div>
            <button 
              onClick={() => window.location.reload()} 
              className="neo-button bg-yellow-400 text-black py-3 px-6 text-sm font-black border-4 shadow-[4px_4px_0_0_rgba(0,0,0,1)] w-full uppercase tracking-widest"
            >
              MUAT ULANG APLIKASI
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

function AppContent() {
  const [isDark, setIsDark] = useState(false);
  const [url, setUrl] = useState('');
  const [activePlatform, setActivePlatform] = useState<string | null>(null);
  const [status, setStatus] = useState('READY');
  const [showInput, setShowInput] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [direction, setDirection] = useState(0);

  const [downloadResult, setDownloadResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertType, setAlertType] = useState<'ERROR' | 'INFO'>('ERROR');
  const [showContact, setShowContact] = useState(false);
  const [view, setView] = useState<'home' | 'credit' | 'tos'>('home');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Ripple effect state
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const newRipple = {
        id: Date.now() + Math.random(),
        x: e.clientX,
        y: e.clientY
      };
      setRipples(prev => [...prev, newRipple]);
      setTimeout(() => {
        setRipples(prev => prev.filter(r => r.id !== newRipple.id));
      }, 800);
    };

    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const errorParam = urlParams.get('error');
    if (errorParam) {
      setAlertType('ERROR');
      setAlertMessage(errorParam.toUpperCase());
      const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
      window.history.replaceState({path: newUrl}, '', newUrl);
    }
  }, []);

  // Direct Download State & Secure Helper Function
  const [downloadingUrl, setDownloadingUrl] = useState<string | null>(null);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<string | null>(null);

  const getProxyUrl = (mediaUrl: string, prefixName: string = "download") => {
    if (!mediaUrl) return "";
    const baseTitle = downloadResult?.title || "";
    const rawTitle = baseTitle ? `${baseTitle}_${prefixName}` : prefixName;
    const cleanPrefix = rawTitle
      .replace(/[^a-zA-Z0-9\s\-_]/g, "") 
      .trim()
      .replace(/\s+/g, "_") 
      .slice(0, 120); 
    const name = cleanPrefix || "media_download";
    const encodedUrl = encodeURIComponent(mediaUrl);
    return `/api/download-file?url=${encodedUrl}&filename=${encodeURIComponent(name)}`;
  };

  const triggerDownload = async (mediaUrl: string, prefixName: string = "download", originalUrl?: string) => {
    if (!mediaUrl) return;
    setDownloadingUrl(mediaUrl);
    
    const baseTitle = downloadResult?.title || "";
    const rawTitle = baseTitle ? `${baseTitle}_${prefixName}` : prefixName;
    
    const cleanPrefix = rawTitle
      .replace(/[^a-zA-Z0-9\s\-_]/g, "")
      .trim()
      .replace(/\s+/g, "_")
      .slice(0, 100) || "media_download";

    // Dedicated CDN Downloader endpoint: forces Content-Disposition: attachment
    // Browser automatically saves the file to device storage instead of opening preview!
    const encodedUrl = encodeURIComponent(mediaUrl);
    const cdnDownloadUrl = `/api/download-file?url=${encodedUrl}&filename=${encodeURIComponent(cleanPrefix)}`;

    try {
      const a = document.createElement('a');
      a.href = cdnDownloadUrl;
      a.setAttribute('download', cleanPrefix);
      document.body.appendChild(a);
      a.click();
      a.remove();
      
      setAlertType('INFO');
      setAlertMessage('MENGUNDUH FILE... FILE AKAN OTOMATIS DISIMPAN DI FOLDER DOWNLOADS.');
    } catch (err) {
      console.error("Direct download trigger error:", err);
      window.location.href = cdnDownloadUrl;
    } finally {
      setTimeout(() => {
        setDownloadingUrl(null);
      }, 2500);
    }
  };

  // Stats State
  const [stats, setStats] = useState<{
    totalRequests: number;
    requestsByPlatform: Record<string, number>;
    dailyRequests: Array<{ date: string; count: number }>;
  } | null>(null);

  // Music Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const music = {
    title: "没有理由 (No Reason)",
    artist: "永彬Ryan.B / 周延英（英子-effie） / DP龙猪",
    albumArt: "https://files.catbox.moe/p68b6y.webp",
    audioFile: "https://raw.githubusercontent.com/NimeAssistent/Kazumaa/main/uploader/1cccc3153d.mp3",
    duration: 218,
    timeSync: [
      { "time": 0.0, "text": "[playing.. noreason]" },
      { "time": 0.9, "text": "永彬Ryan.B / 周延英（英子-effie） / DP龙猪" },
      { "time": 1.0, "text": "introo" },
      { "time": 3.0, "text": "🎶🎶" },
      { "time": 9.0, "text": "沒有人可以去等待\nTidak ada yang bisa menunggu" },
      { "time": 13.5, "text": "不知不覺的放開你\nTanpa sadar melepaskanmu" },
      { "time": 16.0, "text": "我們都沒有那勇氣 baby\nKita semua tidak punya keberanian itu, sayang" },
      { "time": 19.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 22.0, "text": "我們都沒有錯與對\nKita semua tidak salah dan benar" },
      { "time": 24.5, "text": "找不到任何一個原因\nAku tidak dapat menemukan satu pun alasan" },
      { "time": 27.0, "text": "沒有理由的離開 baby\nTidak ada alasan untuk pergi, sayang" },
      { "time": 30.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 33.0, "text": "Yeah, yeah 看見信息不是不想回你\nYa, ya, melihat pesan bukan berarti tidak ingin membalasmu" },
      { "time": 36.0, "text": "只是我們的對話少了一些甜蜜\nHanya saja percakapan kita kurang sedikit manis" },
      { "time": 38.5, "text": "看似很正常的語句 但透著距離\nTampaknya seperti pernyataan biasa, namun mengungkapkan jarak" },
      { "time": 40.5, "text": "我不知道該怎麽對你 也許是正常的關係\nAku tak tahu apa yang harus kulakukan padamu. Mungkin ini normal" },
      { "time": 43.9, "text": "我每時每刻都告訴自己\nAku selalu mengatakan itu pada diri aku sendiri" },
      { "time": 46.5, "text": "我還是很愛你的 只是 lonely\nAku masih mencintaimu. Aku hanya kesepian" },
      { "time": 50.0, "text": "不知道微信什麽時候開始沒有表情\nTidak tahu kapan obrolan WeChat mulai kehilangan emoji" },
      { "time": 55.0, "text": "你的上班時間多了 沒有那麽多的高興\nKau bekerja lebih lama, kau tidak sebahagia yang seharusnya" },
      { "time": 58.0, "text": "回想起來 剛開始的時間\nMengingat kembali, waktu awalnya" },
      { "time": 60.0, "text": "兩個人都在愛 都想辦法離開\nKeduanya saling mencintai, tetapi berusaha mencari cara untuk pergi" },
      { "time": 62.0, "text": "沒有理由的\nTidak ada alasan untuk pergi" },
      { "time": 65.0, "text": "沒有人可以去等待\nTidak ada yang bisa menunggu" },
      { "time": 67.5, "text": "不知不覺的放開你\nTanpa sadar melepaskanmu" },
      { "time": 72.0, "text": "我們都沒有那勇氣 baby\nKita semua tidak punya keberanian itu, sayang" },
      { "time": 75.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 78.0, "text": "我們都沒有錯與對\nKita semua tidak salah dan benar" },
      { "time": 81.0, "text": "找不到任何一個原因\nAku tidak dapat menemukan satu pun alasan" },
      { "time": 83.0, "text": "沒有理由的離開 baby\nTidak ada alasan untuk pergi, sayang" },
      { "time": 86.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 88.0, "text": "Yeah 理由 理由 理由 理由\nYa alasan alasan alasan alasan" },
      { "time": 95.0, "text": "再多理由 無法挽留\nTidak ada alasan untuk tetap tinggal" },
      { "time": 100.0, "text": "愛情 愛情 愛情 愛情\nCinta cinta cinta cinta" },
      { "time": 106.0, "text": "再多理由 說停就停\nSemakin banyak alasan untuk berhenti" },
      { "time": 111.0, "text": "回想起來 剛開始的時間\nMengingat kembali, waktu awalnya" },
      { "time": 116.0, "text": "兩個人都在愛 都想辦法離開\nKeduanya saling mencintai, tetapi berusaha mencari cara untuk pergi" },
      { "time": 118.0, "text": "沒有理由的\nTidak ada alasan untuk pergi" },
      { "time": 121.0, "text": "沒有人可以去等待\nTidak ada yang bisa menunggu" },
      { "time": 123.0, "text": "不知不覺的放開你\nTanpa sadar melepaskanmu" },
      { "time": 128.0, "text": "我們都沒有那勇氣 baby\nKita semua tidak punya keberanian itu, sayang" },
      { "time": 130.5, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 133.0, "text": "我們都沒有錯與對\nKita semua tidak salah dan benar" },
      { "time": 136.5, "text": "找不到任何一個原因\nAku tidak dapat menemukan satu pun alasan" },
      { "time": 139.0, "text": "沒有理由的離開 baby\nTidak ada alasan untuk pergi, sayang" },
      { "time": 142.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 144.0, "text": "Yeah.. uhuu... ehemmm... " },
      { "time": 154.0, "text": "I'm so lonely\nAku sangat kesepian" },
      { "time": 157.0, "text": "Yeah... huu... Ehemm..." },
      { "time": 167.0, "text": "沒有人可以去等待\nTidak ada yang bisa menunggu" },
      { "time": 170.5, "text": "不知不覺的放開你\nTanpa sadar melepaskanmu" },
      { "time": 173.5, "text": "我們都沒有那勇氣 baby\nKita semua tidak punya keberanian itu, sayang" },
      { "time": 175.5, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 179.0, "text": "我們都沒有錯與對\nKita semua tidak salah dan benar" },
      { "time": 181.0, "text": "找不到任何一個原因\nAku tidak dapat menemukan satu pun alasan" },
      { "time": 184.0, "text": "沒有理由的離開 baby\nTidak ada alasan untuk pergi, sayang" },
      { "time": 187.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 190.0, "text": "Huu..Huu...huu" },
      { "time": 198.0, "text": "I'm sorry, I'm so lonely\nAku minta maaf, Aku sangat kesepian" },
      { "time": 201.0, "text": "Huu..Huu...huu" },
      { "time": 209.0, "text": "[🎶🎶]" },
      { "time": 209.0, "text": "[🎶🎶]" }
    ]
  };

  useEffect(() => {
    // Sync playing state if audio is already playing/paused
    if (audioRef.current) {
      setIsPlaying(!audioRef.current.paused);
    }
  }, [view]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/stats');
        if (res.ok) {
          const contentType = res.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await res.json();
            setStats(data);
          }
        }
      } catch (err: any) {
        if (!err.message?.includes('Failed to fetch')) {
          console.error("Failed to fetch stats:", err);
        }
      }
    };
    
    fetchStats();
    const interval = setInterval(fetchStats, 10000); // refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const currentLyric = music.timeSync.reduce((prev, curr) => {
    if (currentTime >= curr.time) return curr.text;
    return prev;
  }, "");

  const platforms = [
    [
      { id: 'tiktok', name: 'TikTok', icon: Music2 },
      { id: 'instagram', name: 'Instagram', icon: Instagram },
      { id: 'youtube', name: 'YouTube', icon: Youtube },
    ],
    [
      { id: 'facebook', name: 'Facebook', icon: Facebook },
      { id: 'douyin', name: 'Douyin', icon: Video },
      { id: 'snackvideo', name: 'SnackVideo', icon: Clapperboard },
    ],
    [
      { id: 'xiaohongshu', name: 'Xiaohongshu', icon: Heart },
      { id: 'twitter', name: 'Twitter/X', icon: Twitter },
      { id: 'bilibili', name: 'Bilibili', icon: Tv },
    ],
    [
      { id: 'kwai', name: 'Kwai', icon: Film },
      { id: 'threads', name: 'Threads', icon: AtSign },
    ]
  ];

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const handlePlatformClick = (platform: string) => {
    setActivePlatform(platform.toUpperCase());
    setStatus(`READY FOR ${platform.toUpperCase()}`);
    setShowInput(true);
    setDownloadResult(null);
    setUrl('');
    
    // Simulate calling external logic
    console.log(`Calling logic for ${platform}/index.js`);
  };

  const handleBackToMenu = () => {
    setShowInput(false);
    setUrl('');
    setActivePlatform(null);
    setStatus('READY');
    setDownloadResult(null);
  };

  const handleDownload = async () => {
    if (!url) {
      setAlertType('ERROR');
      setAlertMessage('PLEASE PASTE A LINK FIRST!');
      return;
    }

    // Platform specific link detection
    const isTikTok = url.includes('tiktok.com');
    const isInstagram = url.includes('instagram.com') || url.includes('instagr.am');
    const isYouTube = url.includes('youtube.com') || url.includes('youtu.be');
    const isFacebook = url.includes('facebook.com') || url.includes('fb.watch');
    const isDouyin = url.includes('douyin.com');
    const isSnackVideo = url.includes('snackvideo.com') || url.includes('sck.io');
    const isXiaohongshu = url.includes('xiaohongshu.com') || url.includes('xhslink.com');
    const isTwitter = url.includes('twitter.com') || url.includes('x.com');
    const isBilibili = url.includes('bilibili.com') || url.includes('b23.tv');
    const isKwai = url.includes('kwai.com') || url.includes('kwai-video.com');
    const isThreads = url.includes('threads.net') || url.includes('threads.com') || url.includes('threadsmate.com');

    let detectedPlatform = activePlatform;

    if (isTikTok) detectedPlatform = 'TIKTOK';
    else if (isInstagram) detectedPlatform = 'INSTAGRAM';
    else if (isYouTube) detectedPlatform = 'YOUTUBE';
    else if (isFacebook) detectedPlatform = 'FACEBOOK';
    else if (isDouyin) detectedPlatform = 'DOUYIN';
    else if (isSnackVideo) detectedPlatform = 'SNACKVIDEO';
    else if (isXiaohongshu) detectedPlatform = 'XIAOHONGSHU';
    else if (isTwitter) detectedPlatform = 'TWITTER';
    else if (isBilibili) detectedPlatform = 'BILIBILI';
    else if (isKwai) detectedPlatform = 'KWAI';
    else if (isThreads) detectedPlatform = 'THREADS';

    if (!detectedPlatform) {
      setAlertType('ERROR');
      setAlertMessage('TIDAK BISA MENDETEKSI PLATFORM DARI LINK INI!');
      return;
    }

    // Auto-switch states if the detected platform is different
    if (detectedPlatform !== activePlatform) {
      setActivePlatform(detectedPlatform);
      setStatus(`READY FOR ${detectedPlatform}`);
      setShowInput(true);
    }

    setLoading(true);
    setDownloadResult(null);
    
    try {
      const safeFetchJson = async (fetchUrl: string) => {
        try {
          const response = await fetch(fetchUrl);
          
          if (!response.ok) {
            let errorMsg = `Server error (${response.status})`;
            try {
              const text = await response.text();
              try {
                const errData = JSON.parse(text);
                if (errData && errData.error) {
                  errorMsg = errData.error;
                }
              } catch (e) {
                if (text && text.length < 200 && !text.startsWith('<')) {
                  errorMsg = text;
                }
              }
            } catch (_) {}
            throw new Error(errorMsg);
          }
          
          const text = await response.text();
          try {
            return JSON.parse(text);
          } catch (err) {
            if (text.trim().startsWith('<')) {
              throw new Error("SERVER IS RESTARTING OR UNAVAILABLE. PLEASE TRY AGAIN IN A MOMENT.");
            }
            throw new Error("Invalid response format from server.");
          }
        } catch (err: any) {
          throw new Error(err.message || "Failed to fetch from server.");
        }
      };

      if (detectedPlatform === 'TIKTOK') {
        // Use local server proxy (works on Vercel via /api directory)
        const data = await safeFetchJson(`/api/proxy/tiktok?url=${encodeURIComponent(url)}`);
        
        if (data && (data.video || data.links || data.dl_links || (data.images && data.images.length > 0) || data.status)) {
          // Handle both API formats
          const videoUrl = data.video || (data.links && data.links.video) || (data.dl_links && data.dl_links.video);
          const title = data.title || "TikTok Video";
          const rawThumbnail = data.thumbnail || "";
          const thumbnail = rawThumbnail.replace(/&amp;/g, '&');

          setDownloadResult({
            title,
            thumbnail,
            video: videoUrl,
            audio: data.audio || (data.links && data.links.audio) || "",
            downloads: data.downloads,
            images: data.images || [],
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'INSTAGRAM') {
        // Use local server proxy (works on Vercel via /api directory)
        const data = await safeFetchJson(`/api/proxy/instagram?url=${encodeURIComponent(url)}`);
        
        if (data && (data.video || (data.downloads && data.downloads.length > 0) || (data.images && data.images.length > 0))) {
          const videoUrl = data.video || "";
          const title = data.title || "Instagram Media";
          const rawThumbnail = data.thumbnail || "";
          const thumbnail = rawThumbnail.replace(/&amp;/g, '&');

          setDownloadResult({
            title,
            thumbnail,
            video: videoUrl,
            downloads: data.downloads,
            images: data.images || [],
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH INSTAGRAM DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'YOUTUBE') {
        // Use backend proxy (Cuki AIO API)
        const data = await safeFetchJson(`/api/proxy/youtube?url=${encodeURIComponent(url)}`);
        
        if (data && data.status && (data.video || data.downloads)) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          const videoUrl = data.video || "";
          setDownloadResult({
            title: data.title || "YouTube Video",
            thumbnail: cleanThumbnail,
            video: videoUrl,
            audio: data.audio || data.music || data.mp3 || "",
            downloads: data.downloads,
            creator: data.author,
            images: data.images || [],
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH YOUTUBE DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'SNACKVIDEO') {
        const data = await safeFetchJson(`/api/proxy/snackvideo?url=${encodeURIComponent(url)}`);
        
        const inner = data?.data || data;
        if (data && data.status && (inner.video || inner.videoUrl || inner.downloads || data.downloads)) {
          const cleanThumbnail = (inner.thumbnail || data.thumbnail || "").replace(/&amp;/g, '&');
          setDownloadResult({
            title: inner.title || data.title || "SnackVideo",
            thumbnail: cleanThumbnail,
            video: inner.videoUrl || inner.video || data.video || "",
            downloads: data.downloads || inner.downloads,
            creator: inner.creator?.name,
            images: inner.images || data.images || [],
            isFallback: data.isFallback || inner.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH SNACKVIDEO DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'FACEBOOK') {
        const data = await safeFetchJson(`/api/proxy/facebook?url=${encodeURIComponent(url)}`);
        const inner = data?.data || data;
        if (data && data.status && (inner.video || inner.videoUrl || inner.downloads || data.downloads || data.video)) {
          const cleanThumbnail = (inner.thumbnail || data.thumbnail || "").replace(/&amp;/g, '&');
          
          let downloads: any[] = [];
          const rawDownloads = data.downloads || inner.downloads || inner.url;
          
          if (Array.isArray(rawDownloads)) {
            downloads = rawDownloads.map((item: any) => ({
              quality: item.quality || "VIDEO",
              url: item.url
            }));
          } else if (inner.videoUrl || inner.video || data.video) {
            downloads.push({ quality: "VIDEO", url: inner.videoUrl || inner.video || data.video });
          }

          setDownloadResult({
            title: inner.title || data.title || "Facebook Video",
            thumbnail: cleanThumbnail,
            downloads: downloads.length > 0 ? downloads : undefined,
            video: inner.videoUrl || inner.video || data.video || "",
            images: inner.images || data.images || [],
            isFallback: data.isFallback || inner.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH FACEBOOK DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'DOUYIN') {
        const data = await safeFetchJson(`/api/proxy/douyin?url=${encodeURIComponent(url)}`);
        const inner = data?.data || data;
        if (data && data.status && (inner.video || inner.videoUrl || inner.downloads || data.downloads || data.video)) {
          const cleanThumbnail = (inner.thumbnail || data.thumbnail || "").replace(/&amp;/g, '&');
          
          setDownloadResult({
            title: inner.title || data.title || "Douyin Video",
            thumbnail: cleanThumbnail,
            video: inner.videoUrl || inner.video || data.video || "",
            downloads: data.downloads || inner.downloads,
            images: inner.images || data.images || [],
            isFallback: data.isFallback || inner.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH DOUYIN DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'XIAOHONGSHU') {
        const data = await safeFetchJson(`/api/proxy/xiaohongshu?url=${encodeURIComponent(url)}`);
        if (data && (data.video || data.downloads || (data.images && data.images.length > 0))) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          setDownloadResult({
            title: data.title || "Xiaohongshu Post",
            thumbnail: cleanThumbnail,
            video: data.video,
            audio: data.audio || data.music || data.mp3 || "",
            downloads: data.downloads,
            images: data.images || [],
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH XIAOHONGSHU DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'TWITTER') {
        const data = await safeFetchJson(`/api/proxy/twitter?url=${encodeURIComponent(url)}`);
        if (data && (data.video || data.downloads || (data.images && data.images.length > 0))) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          setDownloadResult({
            title: data.title || "Twitter/X Media",
            thumbnail: cleanThumbnail,
            video: data.video,
            audio: data.audio || data.music || data.mp3 || "",
            downloads: data.downloads,
            images: data.images || [],
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH TWITTER/X DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'BILIBILI') {
        const data = await safeFetchJson(`/api/proxy/bilibili?url=${encodeURIComponent(url)}`);
        if (data && (data.video || data.downloads)) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          setDownloadResult({
            title: data.title || "Bilibili Video",
            thumbnail: cleanThumbnail,
            video: data.video,
            audio: data.audio || data.music || data.mp3 || "",
            downloads: data.downloads,
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH BILIBILI DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'KWAI') {
        const data = await safeFetchJson(`/api/proxy/kwai?url=${encodeURIComponent(url)}`);
        if (data && (data.video || data.downloads)) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          setDownloadResult({
            title: data.title || "Kwai Video",
            thumbnail: cleanThumbnail,
            video: data.video,
            audio: data.audio || data.music || data.mp3 || "",
            downloads: data.downloads,
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH KWAI DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else if (detectedPlatform === 'THREADS') {
        const data = await safeFetchJson(`/api/proxy/threads?url=${encodeURIComponent(url)}`);
        if (data && (data.video || data.downloads || (data.images && data.images.length > 0))) {
          const cleanThumbnail = data.thumbnail ? data.thumbnail.replace(/&amp;/g, '&') : "";
          setDownloadResult({
            title: data.title || "Threads Post",
            thumbnail: cleanThumbnail,
            video: data.video,
            downloads: data.downloads,
            images: data.images,
            isFallback: data.isFallback
          });
          setStatus('DOWNLOAD READY');
        } else {
          const errorMsg = data?.error || 'FAILED TO FETCH THREADS DATA.';
          setAlertType('ERROR');
          setAlertMessage(errorMsg.toUpperCase());
        }
      } else {
        setAlertType('ERROR');
        setAlertMessage(`${detectedPlatform} COMING SOON!`);
      }
    } catch (e: any) {
      setAlertType('ERROR');
      const displayMsg = e.message || 'DOWNLOAD FAILED. TRY AGAIN.';
      setAlertMessage(displayMsg.toUpperCase());
      setStatus('ERROR');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center p-4 pt-10 pb-20 gap-20 transition-colors duration-500">
      
      {/* Global Ripple Effect */}
      <div className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden">
        <AnimatePresence>
          {ripples.map(ripple => (
            <motion.div
              key={ripple.id}
              initial={{ scale: 0, opacity: 0.6, borderWidth: "4px" }}
              animate={{ scale: 4, opacity: 0, borderWidth: "1px" }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute w-12 h-12 rounded-full border-black dark:border-white drop-shadow-[2px_2px_0_rgba(0,0,0,0.5)] dark:drop-shadow-[2px_2px_0_rgba(255,255,255,0.5)]"
              style={{
                left: ripple.x - 24,
                top: ripple.y - 24,
              }}
            />
          ))}
        </AnimatePresence>
      </div>

      <div className="neo-card w-full max-w-md p-6 relative flex flex-col min-h-[500px]">
        {/* Action Buttons (Dark Mode) */}
        <div className="absolute top-20 right-4 flex gap-3 z-40">
          <button 
            onClick={() => setIsDark(!isDark)}
            className="neo-button neo-button-sm p-2 bg-white dark:bg-zinc-800"
          >
            {isDark ? (
              <Sun className="w-5 h-5 text-yellow-400" />
            ) : (
              <Moon className="w-5 h-5 text-indigo-600" />
            )}
          </button>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-center gap-4 mb-6 z-30">
          <button 
            onClick={() => setView('home')}
            className={`neo-button px-6 py-2 text-xs font-black tracking-widest transition-all ${
              view === 'home' ? 'bg-white text-black' : 'bg-red-500 text-white'
            }`}
          >
            HOME
          </button>
          <button 
            onClick={() => setView('credit')}
            className={`neo-button px-6 py-2 text-xs font-black tracking-widest transition-all ${
              view === 'credit' ? 'bg-white text-black' : 'bg-red-500 text-white'
            }`}
          >
            CREDIT
          </button>
        </div>

        <AnimatePresence mode="wait">
          {view === 'home' ? (
            <motion.div
              key="home-view"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col h-full"
            >
              {/* Thumbnail Slider (0.4s fade) */}
        <div className="mb-6">
          <div className="slider-container">
            <div className="slider-item">
              <img src="/images/1.jpg" alt="Slide 1" />
            </div>
            <div className="slider-item">
              <img src="/images/2.jpg" alt="Slide 2" />
            </div>
            <div className="slider-item">
              <img src="/images/3.jpg" alt="Slide 3" />
            </div>
            <div className="slider-item">
              <img src="/images/4.jpg" alt="Slide 4" />
            </div>
            <div className="slider-item">
              <img src="/images/5.jpg" alt="Slide 5" />
            </div>
            <div className="slider-item">
              <img src="/images/6.jpg" alt="Slide 6" />
            </div>

            {/* Chibi Character Overlay (Himmel) */}
            <div className="absolute bottom-2 right-2 z-20 pointer-events-none select-none">
              <img 
                src="/images/himmel_chibi.png" 
                alt="Chibi Himmel" 
                className="h-16 w-auto drop-shadow-[2.5px_2.5px_0px_rgba(0,0,0,1)] filter contrast-110 brightness-105"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          </div>
        </div>

        {/* Title & Description */}
        <div className="text-center mb-6">
          <h1 className="font-display text-3xl font-black mb-2 tracking-tight text-[var(--text-name)]">
            Taufik Hidayat
          </h1>
          <p className="text-sm font-bold opacity-100 px-4 text-[var(--text-desc)]">
            Ini Adalah Website Downloader Simpel, Support Platform YouTube, TikTok, Instagram, Threads, Facebook, Douyin, Xiaohongshu, Twitter/X, Bilibili, Kwai, & SnackVideo
          </p>
        </div>

        {/* Animated Input Area */}
        <AnimatePresence mode="wait">
          {showInput && (
            <motion.div
              key="input-area"
              initial={{ y: 50, opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ y: 0, opacity: 1, height: 'auto', marginBottom: 24 }}
              exit={{ y: -50, opacity: 0, height: 0, marginBottom: 0 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
              className="overflow-hidden"
            >
              <div className="mb-4 flex gap-2 items-center">
                <input 
                  type="text" 
                  placeholder={`Paste ${activePlatform?.toLowerCase()} link here...`}
                  className="neo-input !bg-white !text-black flex-1"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
                <button
                  onClick={async () => {
                    try {
                      const text = await navigator.clipboard.readText();
                      if (text) setUrl(text.trim());
                    } catch (err) {
                      console.warn('Clipboard access denied:', err);
                    }
                  }}
                  className="neo-button bg-[#51FFFE] hover:bg-[#51FFFE]/80 text-black p-3 border-[3px] border-black shadow-[3px_3px_0_0_rgba(0,0,0,1)] flex items-center justify-center shrink-0 transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-[1px_1px_0_0_rgba(0,0,0,1)]"
                  title="Paste from clipboard"
                >
                  <ClipboardPaste className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  onClick={handleDownload}
                  disabled={loading}
                  className="neo-button neo-button-lg neo-button-yellow py-4 flex items-center justify-center gap-2 text-lg disabled:opacity-50"
                >
                  {loading && <Loader2 className="w-6 h-6 animate-spin" />}
                  {!loading && <Download className="w-6 h-6" />}
                  {loading && <span>PROCESSING...</span>}
                  {!loading && <span>DOWNLOAD NOW</span>}
                </button>

                {/* Loading / Processing State */}
                {loading && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-5 border-[3px] border-black rounded-xl bg-amber-50 dark:bg-zinc-800 text-black dark:text-white shadow-[4px_4px_0_0_rgba(0,0,0,1)] flex flex-col gap-4 items-center justify-center text-center font-sans"
                  >
                    <div className="w-12 h-12 bg-[#51FFFE] rounded-full border-[3px] border-black flex items-center justify-center animate-bounce">
                      <Loader2 className="w-6 h-6 animate-spin text-black" />
                    </div>
                    <div>
                      <h3 className="font-display font-black text-lg uppercase tracking-tight">Processing Media Link...</h3>
                      <p className="text-xs font-bold opacity-75 mt-1 font-mono">Connecting to high-speed download node</p>
                    </div>
                    <div className="w-full bg-zinc-200 border-2 border-black rounded-full h-4 overflow-hidden relative">
                      <div className="bg-[#FF60B5] h-full w-2/3 border-r-2 border-black" />
                    </div>
                    <div className="flex gap-3 mt-2 items-center justify-center">
                      <motion.div
                        className="w-4 h-4 rounded-full bg-[#FF60B5] border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)]"
                        animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0 }}
                      />
                      <motion.div
                        className="w-4 h-4 rounded-full bg-[#51FFFE] border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)]"
                        animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0.2 }}
                      />
                      <motion.div
                        className="w-4 h-4 rounded-full bg-[#00FF94] border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)]"
                        animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0.4 }}
                      />
                    </div>
                  </motion.div>
                )}

                {/* Result Display */}
                {!loading && downloadResult && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 border-2 border-black rounded-xl bg-zinc-50 dark:bg-zinc-800/50 flex flex-col gap-3 text-black dark:text-white"
                  >
                    <div className="text-xs font-black uppercase tracking-tighter opacity-50 text-black dark:text-white font-mono">Result Found</div>

                    {/* Media Preview Player Section */}
                    {(() => {
                      const videoUrl = downloadResult.video || 
                                       downloadResult.links?.video || 
                                       (Array.isArray(downloadResult.dl_links) && downloadResult.dl_links.find((l: any) => l && (l.type || '').toString().includes('HD'))?.link) ||
                                       (Array.isArray(downloadResult.downloads) && downloadResult.downloads.find((d: any) => {
                                         const q = (d?.quality || '').toString().toLowerCase();
                                         const ext = (d?.ext || '').toString().toLowerCase();
                                         if (ext === 'jpg' || ext === 'png' || ext === 'jpeg' || ext === 'webp') return false;
                                         return q.includes('video') || q.includes('mp4') || q.includes('hd') || q.includes('watermark') || ext === 'mp4';
                                       })?.url);
                      
                      const audioUrl = downloadResult.audio || 
                                       downloadResult.music || 
                                       downloadResult.mp3 || 
                                       downloadResult.links?.audio ||
                                       (Array.isArray(downloadResult.downloads) && downloadResult.downloads.find((d: any) => d && ((d.quality || '').toString().toLowerCase().includes('mp3') || (d.quality || '').toString().toLowerCase().includes('audio')))?.url);

                      if (videoUrl) {
                        const proxiedVideoUrl = `/api/stream-proxy?url=${encodeURIComponent(String(videoUrl))}`;
                        const proxiedAudioForSync = audioUrl ? `/api/stream-proxy?url=${encodeURIComponent(String(audioUrl))}` : null;
                        
                        return (
                          <div className="w-full rounded-xl overflow-hidden border-[3px] border-black bg-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] mb-1">
                            <div className="bg-[#51FFFE] text-black font-black text-[10px] px-3 py-1.5 border-b-[3px] border-black flex items-center justify-between uppercase tracking-wider font-sans">
                              <span className="flex items-center gap-1.5">🎬 LIVE VIDEO PREVIEW</span>
                              <a 
                                href={videoUrl.includes('googlevideo.com') ? '#' : videoUrl} 
                                target={videoUrl.includes('googlevideo.com') ? '_self' : '_blank'} 
                                rel="noopener noreferrer" 
                                onClick={(e) => {
                                  if (videoUrl.includes('googlevideo.com')) {
                                    e.preventDefault();
                                    setAlertType('ERROR');
                                    setAlertMessage('LINK INI DIBLOKIR OLEH GOOGLE (IP BINDING). COBA MENGGUNAKAN TOMBOL SERVER UNTUK DOWNLOAD.');
                                  }
                                }}
                                className="neo-button bg-black text-white px-4 py-2 font-black border-2 border-transparent hover:border-black hover:bg-white hover:text-black transition-all"
                              >
                                BUKA VIDEO
                              </a>
                            </div>
                            <video 
                              src={proxiedVideoUrl} 
                              controls 
                              playsInline
                              preload="metadata"
                              className="w-full max-h-[280px] mx-auto block font-sans"
                              poster={downloadResult.thumbnail}
                              referrerPolicy="no-referrer"
                              onError={(e) => {
                                if (e.currentTarget.src !== videoUrl) {
                                  console.log("Stream proxy failed, falling back to direct video url");
                                  e.currentTarget.src = videoUrl;
                                }
                              }}
                              onPlay={(e) => {
                                const audio = e.currentTarget.parentElement?.querySelector('audio');
                                if (audio) { audio.currentTime = e.currentTarget.currentTime; audio.play().catch(() => {}); }
                              }}
                              onPause={(e) => {
                                const audio = e.currentTarget.parentElement?.querySelector('audio');
                                if (audio) audio.pause();
                              }}
                              onSeeked={(e) => {
                                const audio = e.currentTarget.parentElement?.querySelector('audio');
                                if (audio) audio.currentTime = e.currentTarget.currentTime;
                              }}
                              onVolumeChange={(e) => {
                                const audio = e.currentTarget.parentElement?.querySelector('audio');
                                if (audio) { audio.volume = e.currentTarget.volume; audio.muted = e.currentTarget.muted; }
                              }}
                            />
                            {proxiedAudioForSync && (
                              <audio 
                                src={proxiedAudioForSync} 
                                preload="metadata"
                                style={{ display: 'none' }}
                              />
                            )}
                          </div>
                        );
                      } else if (audioUrl) {
                        const proxiedAudioUrl = `/api/stream-proxy?url=${encodeURIComponent(String(audioUrl))}`;
                        return (
                          <div className="w-full p-4 rounded-xl border-[3px] border-black bg-red-50 dark:bg-red-950/20 shadow-[4px_4px_0_0_rgba(0,0,0,1)] mb-1 dark:text-white">
                            <div className="bg-[#FF60B5] border-[3px] border-black text-black font-black text-[10px] px-3 py-1.5 flex items-center justify-between uppercase tracking-wider rounded-lg mb-3 font-sans">
                              <span className="flex items-center gap-1.5 font-sans">🎵 LIVE MUSIC PREVIEW</span>
                              <a 
                                href={audioUrl.includes('googlevideo.com') ? '#' : audioUrl} 
                                target={audioUrl.includes('googlevideo.com') ? '_self' : '_blank'} 
                                rel="noopener noreferrer" 
                                onClick={(e) => {
                                  if (audioUrl.includes('googlevideo.com')) {
                                    e.preventDefault();
                                    setAlertType('ERROR');
                                    setAlertMessage('LINK INI DIBLOKIR OLEH GOOGLE (IP BINDING). COBA MENGGUNAKAN TOMBOL SERVER UNTUK DOWNLOAD.');
                                  }
                                }}
                                className="neo-button bg-pink-500 text-black px-4 py-2 font-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] uppercase tracking-wider"
                              >
                                BUKA AUDIO
                              </a>
                            </div>
                            {downloadResult.thumbnail && (
                              <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-black bg-black/5 mx-auto mb-2.5 shadow">
                                <img 
                                  src={downloadResult.thumbnail} 
                                  alt="Audio Thumbnail" 
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                            )}
                            <audio 
                              src={proxiedAudioUrl} 
                              controls 
                              preload="metadata"
                              className="w-full border-2 border-black rounded-lg"
                              referrerPolicy="no-referrer"
                              onError={(e) => {
                                if (e.currentTarget.src !== audioUrl) {
                                  console.log("Stream proxy failed, falling back to direct audio url");
                                  e.currentTarget.src = audioUrl;
                                }
                              }}
                            />
                          </div>
                        );
                      } else if (downloadResult.thumbnail) {
                        return (
                          <div className="w-full rounded-xl overflow-hidden border-[3px] border-black bg-black/5 mb-1 shadow-[4px_4px_0_0_rgba(0,0,0,1)]">
                            <img 
                              src={downloadResult.thumbnail} 
                              alt="Thumbnail" 
                              className="w-full h-auto block"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        );
                      }
                      return null;
                    })()}

                    <div className="text-sm font-bold">{downloadResult.title ? String(downloadResult.title) : 'No Title'}</div>

                    {(() => {
                      const dlArray = Array.isArray(downloadResult.downloads) ? downloadResult.downloads : [];
                      const has4K = dlArray.some((dl: any) => {
                        const q = (dl?.quality || '').toString().toLowerCase();
                        return q.includes('4k') || q.includes('2160p') || q.includes('3840x2160');
                      }) || false;

                      let totalFormatsCount = dlArray.length;
                      if (totalFormatsCount === 0) {
                        if (downloadResult.video) totalFormatsCount++;
                        if (downloadResult.audio) totalFormatsCount++;
                      }

                      const showNote = !has4K || totalFormatsCount === 1;

                      if (showNote) {
                        return (
                          <div className="bg-yellow-300 text-black border-2 border-black p-2.5 font-bold text-xs flex items-center justify-center gap-1.5 rounded-lg">
                            <span>ℹ️</span> Hanya tersedia format ini
                          </div>
                        );
                      }
                      return null;
                    })()}
                    
                    <div className="flex flex-col gap-3 mt-2">
                      {/* Master Download Selections */}
                      {(() => {
                        const videoUrl = downloadResult.video || 
                                         downloadResult.links?.video || 
                                         (Array.isArray(downloadResult.dl_links) && downloadResult.dl_links.find((l: any) => l && (l.type || '').toString().includes('HD'))?.link) ||
                                         (Array.isArray(downloadResult.downloads) && downloadResult.downloads.find((d: any) => {
                                         const q = (d?.quality || '').toString().toLowerCase();
                                         const ext = (d?.ext || '').toString().toLowerCase();
                                         if (ext === 'jpg' || ext === 'png' || ext === 'jpeg' || ext === 'webp') return false;
                                         return q.includes('video') || q.includes('mp4') || q.includes('hd') || q.includes('watermark') || ext === 'mp4';
                                       })?.url);
                        
                        const audioUrl = downloadResult.audio || 
                                         downloadResult.music || 
                                         downloadResult.mp3 || 
                                         downloadResult.links?.audio ||
                                         (Array.isArray(downloadResult.downloads) && downloadResult.downloads.find((d: any) => d && ((d.quality || '').toString().toLowerCase().includes('mp3') || (d.quality || '').toString().toLowerCase().includes('audio')))?.url);

                        const isDownloadingVideo = downloadingUrl === videoUrl;
                        const isDownloadingAudio = downloadingUrl === audioUrl;

                        return (
                          <>
                            {/* VIDEO DOWNLOAD BUTTON */}
                            {videoUrl && (
                              <button 
                                onClick={() => {
                                  if (downloadingUrl !== null) return;
                                  triggerDownload(videoUrl, 'video', url);
                                }}
                                disabled={downloadingUrl !== null}
                                className={`neo-button bg-[#51FFFE] hover:bg-[#51FFFE]/90 text-black py-3.5 text-sm font-black flex items-center justify-center gap-2 border-[3px] shadow-[3px_3px_0_0_rgba(0,0,0,1)] ${downloadingUrl !== null ? 'opacity-50 pointer-events-none' : ''}`}
                              >
                                {isDownloadingVideo && <Loader2 className="w-5 h-5 animate-spin" />}
                                {!isDownloadingVideo && <Download className="w-5 h-5" />}
                                {isDownloadingVideo && <span>DOWNLOADING VIDEO...</span>}
                                {!isDownloadingVideo && <span>DOWNLOAD VIDEO</span>}
                              </button>
                            )}

                            {/* AUDIO DOWNLOAD BUTTON */}
                            {audioUrl && (
                              <button 
                                onClick={() => {
                                  if (downloadingUrl !== null) return;
                                  triggerDownload(audioUrl, 'audio', url);
                                }}
                                disabled={downloadingUrl !== null}
                                className={`neo-button bg-[#FF60B5] hover:bg-[#FF60B5]/90 text-white py-3.5 text-sm font-black flex items-center justify-center gap-2 border-[3px] shadow-[3px_3px_0_0_rgba(0,0,0,1)] ${downloadingUrl !== null ? 'opacity-50 pointer-events-none' : ''}`}
                              >
                                {isDownloadingAudio && <Loader2 className="w-5 h-5 animate-spin" />}
                                {!isDownloadingAudio && <Download className="w-5 h-5" />}
                                {isDownloadingAudio && <span>DOWNLOADING AUDIO...</span>}
                                {!isDownloadingAudio && <span>DOWNLOAD AUDIO (MP3)</span>}
                              </button>
                            )}
                          </>
                        );
                      })()}

                      {/* Display Alternative Channels/Servers if multiple downloads exist */}
                      {Array.isArray(downloadResult.downloads) && downloadResult.downloads.length > 0 && (
                        <div className="mt-2 border-t-2 border-dashed border-black/20 dark:border-white/20 pt-3">
                          <p className="text-[10px] font-black uppercase tracking-widest text-[#FF60B5] dark:text-[#51FFFE] mb-2 text-center">
                            🌐 ALTERNATIVE SERVERS / QUALITY FORMATS
                          </p>
                          <div className="flex flex-col gap-2.5 max-h-60 overflow-y-auto pr-1">
                            {downloadResult.downloads.map((dl: any, idx: number) => {
                              const isDownloading = downloadingUrl === dl?.url;
                              return (
                                <div key={idx} className="flex gap-2 items-center w-full font-sans">
                                  <button 
                                    onClick={() => {
                                      if (!dl?.url || downloadingUrl !== null) return;
                                      triggerDownload(dl.url, `download_server_${idx + 1}`, url);
                                    }}
                                    disabled={!dl?.url || downloadingUrl !== null}
                                    className={`neo-button py-2 px-3 text-xs font-black flex items-center justify-center gap-1.5 flex-1 border-2 shadow-[2px_2px_0_0_rgba(0,0,0,1)] ${
                                      (dl?.quality || '').toString().toLowerCase().includes('mp3') || (dl?.quality || '').toString().toLowerCase().includes('audio') ? 'bg-[#FF60B5] text-white' : 'bg-[#51FFFE] text-black'
                                    } ${downloadingUrl !== null ? 'opacity-50 pointer-events-none' : ''}`}
                                  >
                                    {isDownloading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                                    {!isDownloading && <Download className="w-3.5 h-3.5" />}
                                    {isDownloading && <span>DOWNLOADING...</span>}
                                    {!isDownloading && <span>{dl?.quality ? String(dl.quality) : `Server #${idx + 1}`}</span>}
                                  </button>

                                  <a 
                                    href={`/api/stream-proxy?url=${encodeURIComponent(dl?.url || '')}`} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="neo-button bg-yellow-400 text-black p-2 border-2 shadow-[2px_2px_0_0_rgba(0,0,0,1)] flex items-center justify-center hover:bg-yellow-300 transition-colors"
                                    title="Tonton Preview di tab baru"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </a>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* EXTERNAL YOUTUBE DOWNLOADERS */}
                      {activePlatform === 'youtube' && (
                        <div className="mt-4 border-t-2 border-black/20 dark:border-white/20 pt-4">
                          <p className="text-[11px] font-black uppercase tracking-widest text-red-500 mb-3 text-center">
                            ⚠️ SERVER YOUTUBE GANGGUAN? GUNAKAN LINK LUAR
                          </p>
                          <div className="flex flex-col gap-3 font-sans">
                            <a 
                              href={`https://cobalt.tools/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="neo-button bg-[#3b82f6] hover:bg-[#2563eb] text-white py-3 text-xs font-black flex items-center justify-center gap-2 border-[3px] shadow-[3px_3px_0_0_rgba(0,0,0,1)]"
                            >
                              <ExternalLink className="w-4 h-4" />
                              DOWNLOAD VIA COBALT (WEB BEBAS IKLAN)
                            </a>
                            <a 
                              href={`https://yt1s.com/en/youtube-to-mp4?q=${encodeURIComponent(url)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="neo-button bg-green-500 hover:bg-green-600 text-white py-3 text-xs font-black flex items-center justify-center gap-2 border-[3px] shadow-[3px_3px_0_0_rgba(0,0,0,1)]"
                            >
                              <ExternalLink className="w-4 h-4" />
                              DOWNLOAD VIA YT1S (OTOMATIS)
                            </a>
                            <a 
                              href={`https://en.savefrom.net/1-youtube-video-downloader-360/?url=${encodeURIComponent(url)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="neo-button bg-blue-500 hover:bg-blue-600 text-white py-3 text-xs font-black flex items-center justify-center gap-2 border-[3px] shadow-[3px_3px_0_0_rgba(0,0,0,1)]"
                            >
                              <ExternalLink className="w-4 h-4" />
                              DOWNLOAD VIA SAVEFROM.NET
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Multiple Images Handling */}
                      {Array.isArray(downloadResult.images) && downloadResult.images.length > 0 && (
                        <div className="mt-3 flex flex-col gap-3 pt-3 border-t-2 border-black/10">
                          <div className="text-xs font-black uppercase tracking-wider text-black dark:text-white opacity-75 flex items-center gap-1">
                            <span>📷</span> Images / Media ({downloadResult.images.length})
                          </div>
                          <div className="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto p-1.5 bg-zinc-200/50 dark:bg-zinc-900/50 border border-black rounded-lg">
                            {downloadResult.images.map((img: any, idx: number) => {
                              const imageUrl = typeof img === 'string' ? img : (img?.url || "");
                              return (
                                <div key={idx} className="relative rounded overflow-hidden border border-black aspect-video bg-zinc-300 dark:bg-zinc-700">
                                  <img 
                                    src={imageUrl} 
                                    alt={`Media ${idx + 1}`} 
                                    className="w-full h-full object-cover" 
                                    referrerPolicy="no-referrer"
                                  />
                                  <div className="absolute top-1 left-1 bg-yellow-400 text-black border border-black font-black text-[9px] px-1 py-0.5 select-none shadow">
                                    #{idx + 1}
                                  </div>
                                  <a 
                                    href={imageUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="absolute bottom-1 right-1 bg-emerald-400 hover:bg-emerald-300 text-black border border-black font-bold text-[9px] px-1.5 py-0.5 shadow"
                                  >
                                    PREVIEW
                                  </a>
                                </div>
                              );
                            })}
                          </div>

                          {/* DOWNLOAD ALL IMAGES BUTTON */}
                          {downloadResult.images.length > 1 && (
                            <button
                              onClick={async () => {
                                const images = downloadResult.images;
                                setDownloadingAll(true);
                                for (let i = 0; i < images.length; i++) {
                                  const img = images[i];
                                  const imageUrl = typeof img === 'string' ? img : (img?.url || "");
                                  if (imageUrl) {
                                    setDownloadProgress(`${i + 1}/${images.length}`);
                                    await triggerDownload(imageUrl, `image_${i + 1}`);
                                    await new Promise(resolve => setTimeout(resolve, 600));
                                  }
                                }
                                setDownloadingAll(false);
                                setDownloadProgress(null);
                              }}
                              disabled={downloadingAll || downloadingUrl !== null}
                              className="neo-button bg-[#00FF94] text-black py-4.5 text-sm font-black flex items-center justify-center gap-2.5 disabled:opacity-50 border-[3px]"
                            >
                              {downloadingAll && <Loader2 className="w-5 h-5 animate-spin text-black" />}
                              {!downloadingAll && <Download className="w-5 h-5 text-black" />}
                              {downloadingAll && <span key={downloadProgress || 'prog'}>{`DOWNLOADING ${downloadProgress || ''}...`}</span>}
                              {!downloadingAll && <span>{`DOWNLOAD ALL IMAGES (${downloadResult.images.length})`}</span>}
                            </button>
                          )}

                          <div className="flex flex-col gap-2 mt-1">
                            {downloadResult.images.map((img: any, idx: number) => {
                              const imageUrl = typeof img === 'string' ? img : (img?.url || "");
                              const isDownloading = downloadingUrl === imageUrl;
                              return (
                                <button 
                                  key={idx}
                                  onClick={() => triggerDownload(imageUrl, `image_${idx + 1}`, url)}
                                  disabled={downloadingUrl !== null || downloadingAll}
                                  className="neo-button bg-yellow-400 text-black py-2.5 text-xs font-black flex items-center justify-center gap-2 disabled:opacity-50"
                                >
                                  {isDownloading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                                  {!isDownloading && <Download className="w-3.5 h-3.5" />}
                                  {isDownloading && <span>DOWNLOADING...</span>}
                                  {!isDownloading && <span>{`DOWNLOAD IMAGE ${idx + 1}`}</span>}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                <button 
                  onClick={handleBackToMenu}
                  className="neo-button neo-button-lg neo-button-red py-3 flex items-center justify-center gap-2 border-[3px] no-shadow"
                >
                  BACK TO MENU
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Custom Alert Modal */}
        <AnimatePresence>
          {alertMessage && (
            <motion.div 
              key="alert-modal"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
              onClick={() => setAlertMessage(null)}
            >
              <motion.div 
                className="neo-card !bg-white p-8 max-w-xs w-full text-center border-4 border-black"
                onClick={(e) => e.stopPropagation()}
              >
                <div className={`${alertType === 'ERROR' ? '!text-black' : 'text-blue-600'} mb-4 flex justify-center`}>
                  <div className={`w-16 h-16 rounded-full border-4 ${alertType === 'ERROR' ? '!border-black' : 'border-blue-600'} flex items-center justify-center`}>
                    <span className="text-4xl font-black">{alertType === 'ERROR' ? '!' : 'i'}</span>
                  </div>
                </div>
                <h2 className="text-xl font-black mb-4 uppercase tracking-tight !text-black">
                  {alertType === 'ERROR' ? 'Attention' : 'Information'}
                </h2>
                <p className="font-bold text-sm mb-6 opacity-100 !text-black">{alertMessage}</p>
                <button 
                  onClick={() => setAlertMessage(null)}
                  className={`neo-button ${alertType === 'ERROR' ? '!bg-black !text-white' : 'bg-blue-400 !text-black'} w-full py-3 no-shadow border-2 border-black`}
                >
                  {alertType === 'ERROR' ? 'GOT IT' : 'TUTUP'}
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Platform Icons (Black Area at Bottom) */}
        <div className="bg-black -mx-6 -mb-6 p-6 mt-12 pb-10 rounded-b-[20px]">
          <div className="flex items-center justify-center gap-3 mb-6">
            {/* Left Nav */}
            <button 
              onClick={() => {
                setDirection(-1);
                setCurrentPage(prev => (prev === 0 ? platforms.length - 1 : prev - 1));
              }}
              className="platform-btn platform-btn-sm !w-9 !h-9 !bg-white !text-black hover:!bg-[var(--accent-cyan)] shrink-0 z-20"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Sliding Platform Container */}
            <div className="relative w-[260px] h-[130px] overflow-hidden shrink-0">
              <AnimatePresence initial={false} custom={direction}>
                <motion.div
                  key={currentPage}
                  custom={direction}
                  variants={{
                    enter: (direction: number) => ({
                      x: direction > 0 ? 200 : -200,
                      opacity: 0
                    }),
                    center: {
                      zIndex: 1,
                      x: 0,
                      opacity: 1
                    },
                    exit: (direction: number) => ({
                      zIndex: 0,
                      x: direction < 0 ? 200 : -200,
                      opacity: 0
                    })
                  }}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{
                    x: { type: "spring", stiffness: 300, damping: 30 },
                    opacity: { duration: 0.2 }
                  }}
                  className="flex justify-center items-start gap-6 absolute inset-0 pt-4 pb-10"
                >
                  {platforms[currentPage].map((platform) => (
                    <div key={platform.id} className="flex flex-col items-center gap-2 shrink-0">
                      <button 
                        onClick={() => handlePlatformClick(platform.id)}
                        className={`platform-btn ${activePlatform === platform.id.toUpperCase() ? 'active' : ''}`}
                      >
                        <platform.icon className="w-7 h-7" />
                      </button>
                      <span className="text-[10px] font-black text-white uppercase tracking-tight opacity-90 whitespace-nowrap">
                        {platform.name}
                      </span>
                    </div>
                  ))}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Right Nav */}
            <button 
              onClick={() => {
                setDirection(1);
                setCurrentPage(prev => (prev === platforms.length - 1 ? 0 : prev + 1));
              }}
              className="platform-btn platform-btn-sm !w-9 !h-9 !bg-white !text-black hover:!bg-[var(--accent-cyan)] shrink-0 z-20"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="flex justify-between items-center text-[10px] font-bold text-black dark:text-white uppercase tracking-widest">
            <div className="flex flex-col">
              <span className="opacity-50">Status</span>
              <span key={status} className="text-[#00FF94] drop-shadow-[1px_1px_0_rgba(0,0,0,1)] dark:drop-shadow-none">{status}</span>
            </div>
            <div className="flex flex-col items-end gap-2">
              <div className="flex gap-2">
                <button
                  onClick={() => setView('tos')}
                  className="neo-button bg-yellow-400 text-black px-4 py-2 text-[10px] font-black tracking-widest no-shadow border-2 text-center"
                >
                  S & K
                </button>
                <a 
                  href="mailto:akitohidata@gmail.com?subject=Keluhan%20/%20Kontak%20-%20Akito%20Hidata"
                  className="neo-button bg-blue-500 text-black dark:text-white px-4 py-2 text-[10px] font-black tracking-widest no-shadow border-2 text-center"
                >
                  CONTACT ME
                </a>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    ) : view === 'credit' ? (
      <motion.div
        key="credit-view"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center justify-center h-full py-10"
      >
        <div className="text-center w-full max-w-xs">
          <div className="flex justify-center items-center mb-6">
            <h2 
              onClick={() => {
                setAlertType('INFO');
                setAlertMessage("اَلسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَا تُهُ \n\nSaya Akito Hidata atau LǐRénXīn mengucapkan terimakasih sebesar besar terhadap diriku yang berjuang sejuah ini dan saya tidak lupa berterima kasih kepada para developer yang telah support dan membantu terutama saat saya sedang bertanya\n\nوَالسَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ .");
              }}
              className="font-display text-4xl font-black tracking-tight text-[var(--text-name)] uppercase cursor-pointer hover:opacity-80 transition-opacity"
            >
              Credits
            </h2>
          </div>

          {/* Music Player */}
          <div className="neo-card !bg-white dark:!bg-zinc-800 p-4 border-4 border-black mb-6 flex flex-col gap-4">
            <audio 
              ref={audioRef} 
              src={music.audioFile} 
              onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
              onEnded={() => setIsPlaying(false)}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 border-2 border-black rounded-lg overflow-hidden shrink-0">
                <img src={music.albumArt} alt="Album Art" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="text-sm font-black truncate text-black dark:text-white">{music.title}</div>
                <div className="text-[10px] font-bold opacity-70 truncate text-black dark:text-white">{music.artist}</div>
              </div>
              <button 
                onClick={togglePlay} 
                className="neo-button p-3 bg-yellow-400 !text-black no-shadow border-2 border-black"
              >
                {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
              </button>
            </div>
            <div className="neo-card !bg-white dark:!bg-black p-4 h-32 flex items-center justify-center text-center overflow-hidden relative">
              <div className="absolute inset-0 opacity-20 pointer-events-none">
                <div className={`w-full h-full ${isDark ? 'bg-[radial-gradient(circle,white_1px,transparent_1px)]' : 'bg-[radial-gradient(circle,black_1px,transparent_1px)]'} bg-[length:10px_10px]`}></div>
              </div>
              <AnimatePresence mode="wait">
                <motion.p 
                  key={currentLyric}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-black dark:text-white text-sm font-bold whitespace-pre-line z-10"
                >
                  {currentLyric}
                </motion.p>
              </AnimatePresence>
            </div>
          </div>

          <div className="neo-card !bg-white dark:!bg-zinc-800 p-6 border-4 border-black">
            <p className="text-xl font-black mb-6 uppercase tracking-widest text-black dark:text-white">
              Big thanks
            </p>
            
            <div className="flex flex-col gap-6 items-center w-full">
              {/* Row 1: Divine & Parental Respect (Vertically Stacked) */}
              <div className="flex flex-col gap-2 items-center text-center">
                <div className="neo-button bg-yellow-400 !text-black px-6 py-2.5 text-xs font-black no-shadow flex items-center gap-2 border-[3px] border-black">
                  <span className="text-sm">✨</span>
                  <span>ALLAH SWT</span>
                </div>
                <span className="font-black text-[#FF60B5] dark:text-[#51FFFE] text-[10px] uppercase tracking-widest my-1">- AND -</span>
                <div className="neo-button bg-yellow-400 !text-black px-6 py-2.5 text-xs font-black no-shadow flex items-center gap-2 border-[3px] border-black">
                  <span className="text-sm">❤️</span>
                  <span>MY PARENTS</span>
                </div>
              </div>

              {/* Row 2: Team Contributors (Vertical List, Photo Left, Name Right) */}
              <div className="w-full border-t-2 border-dashed border-black/25 dark:border-white/25 pt-5 mt-2">
                <p className="text-[10px] font-black uppercase tracking-widest text-center text-zinc-500 dark:text-zinc-400 mb-4">
                  👥 CORE CONTRIBUTORS
                </p>
                <div className="flex flex-col gap-3.5 w-full max-w-sm mx-auto">
                  {/* AKITO HIDATA */}
                  <div className="flex items-center gap-4 p-3 border-2 border-black bg-[#51FFFE]/10 dark:bg-[#51FFFE]/5 rounded-lg group hover:bg-[#51FFFE]/20 transition-all">
                    <div className="w-12 h-12 rounded-full border-2 border-black bg-[#51FFFE] shadow-[2px_2px_0_0_rgba(0,0,0,1)] overflow-hidden shrink-0">
                      <img 
                        src="/images/hidata.jpg" 
                        alt="Akito Hidata" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80";
                        }}
                      />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-black text-xs uppercase tracking-wider text-black dark:text-white">
                        AKITO HIDATA
                      </span>
                      <span className="text-[9px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-widest mt-0.5">
                        Lead Developer
                      </span>
                    </div>
                  </div>

                  {/* CINDY */}
                  <div className="flex items-center gap-4 p-3 border-2 border-black bg-[#FF60B5]/10 dark:bg-[#FF60B5]/5 rounded-lg group hover:bg-[#FF60B5]/20 transition-all">
                    <div className="w-12 h-12 rounded-full border-2 border-black bg-[#FF60B5] shadow-[2px_2px_0_0_rgba(0,0,0,1)] overflow-hidden shrink-0">
                      <img 
                        src="/images/cindy.jpg" 
                        alt="Cindy" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80";
                        }}
                      />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-black text-xs uppercase tracking-wider text-black dark:text-white">
                        CINDY
                      </span>
                      <span className="text-[9px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-widest mt-0.5">
                        My Role Model & Support
                      </span>
                    </div>
                  </div>

                  {/* PENYEDIA REST API */}
                  <div className="flex items-center gap-4 p-3 border-2 border-black bg-[#FF4D4D]/10 dark:bg-[#FF4D4D]/5 rounded-lg group hover:bg-[#FF4D4D]/20 transition-all">
                    <div className="w-12 h-12 rounded-full border-2 border-black bg-[#FF4D4D] shadow-[2px_2px_0_0_rgba(0,0,0,1)] overflow-hidden shrink-0">
                      <img 
                        src="/images/penyedia_api.jpg" 
                        alt="Penyedia REST API" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&h=150&q=80";
                        }}
                      />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="font-black text-xs uppercase tracking-wider text-black dark:text-white">
                        PENYEDIA API
                      </span>
                      <span className="text-[9px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-widest mt-0.5">
                        API Integrator
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    ) : view === 'tos' ? (
      <motion.div
        key="tos-view"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center h-full py-6 text-black dark:text-white"
      >
        <div className="w-full text-left bg-white dark:bg-zinc-800 p-6 md:p-8 border-[3px] md:border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[6px_6px_0_0_rgba(0,0,0,1)] max-h-[500px] overflow-y-auto">
          <h2 className="text-2xl md:text-3xl font-black uppercase mb-4 tracking-tight leading-tight">Syarat & Ketentuan</h2>
          <div className="space-y-4 text-xs md:text-sm font-bold opacity-90 leading-relaxed">
            <p>Halo! Kalau kamu mau pakai Akitohidata Downloader, baca dulu ya aturan mainnya di sini. Dengan pakai layanan ini, berarti kamu udah setuju sama semua aturan di bawah. Kalau nggak setuju, mending jangan dipakai ya.</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">1. Tentang Layanan Ini</h3>
            <p>Akitohidata Downloader cuma alat bantu buat bantu kamu ngekstrak dan download media dari berbagai sosial media pakai link publik yang kamu masukin. Kita nggak pernah nyimpen, nge-reupload, atau ngeklaim hak cipta dari media apa pun. Semua file itu ada di server aslinya, kita cuma bantu ngambilin aja.</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">2. Yang Boleh Kamu Lakuin</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Download konten buat disimpen dan dinikmati sendiri (pribadi).</li>
              <li>Download konten bikinan kamu sendiri dari platform lain.</li>
              <li>Download konten yang emang open license atau udah dapet izin dari kreatornya.</li>
            </ul>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">3. Yang DILARANG Keras</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Download dan ngejual/nyebarin karya orang lain tanpa izin (pelanggaran hak cipta).</li>
              <li>Pakai bot, spam, atau scraping gila-gilaan yang bisa bikin server kita down.</li>
              <li>Dipakai buat hal-hal ilegal yang ngelanggar hukum.</li>
              <li>Nyalahgunain layanan ini di luar batas wajar.</li>
            </ul>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">4. Urusan Hak Cipta</h3>
            <p>Semua hak cipta video/foto yang kamu download tetep punya kreator aslinya. Akitohidata Downloader nggak punya hak apa-apa atas konten itu. Jadi, kalau ada masalah dari file yang kamu simpen, itu sepenuhnya tanggung jawab kamu ya.</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">5. Ketersediaan Server</h3>
            <p>Kita usahain web ini selalu on. Tapi, karena kita nebeng API dan sistem pihak ketiga (kayak TikTok, IG, dll), kita nggak jamin bisa lancar 100% terus. Kalau dari sananya berubah, fitur kita bisa aja error atau mati sementara.</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">6. Privasi & Keamanan</h3>
            <p>Kamu nggak perlu bikin akun atau login buat pakai web ini. Link yang kamu masukin cuma diproses saat itu juga dan nggak kita simpen permanen. Aman pokoknya!</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">7. Perubahan Aturan</h3>
            <p>Aturan ini bisa aja berubah sewaktu-waktu kalau memang dibutuhin.</p>
            
            <h3 className="text-lg font-black uppercase mt-6 mb-2">8. Kontak</h3>
            <p>Kalau ada error, nemu bug, atau ada masalah soal hak cipta, langsung aja kontak ke: <a href="mailto:akitohidata@gmail.com" className="text-blue-600 dark:text-blue-400 underline">akitohidata@gmail.com</a> atau klik tombol Contact di menu utama.</p>
          </div>
        </div>
      </motion.div>
    ) : null}
  </AnimatePresence>
</div>

{/* New Landing Page Sections */}
<div className="w-full max-w-5xl flex flex-col gap-16 md:gap-24 mt-8 px-4 text-center text-black dark:text-white pb-10">
  {/* Features Section */}
  <section className="flex flex-col gap-6 md:gap-10 items-center">
    <h2 className="text-2xl md:text-4xl font-black tracking-tight uppercase">Mengapa Pilih Downloader Ini?</h2>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 w-full text-left">
      <div className="neo-card bg-white dark:bg-zinc-800 p-3 md:p-8 border-[3px] md:border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-1.5 md:gap-4 text-black dark:text-white">
        <div className="w-8 h-8 md:w-12 md:h-12 bg-[#00FF94] border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-black rounded flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-xs md:text-lg mt-1 md:mt-2 uppercase tracking-tight leading-tight">Super Ngebut</h3>
        <p className="font-bold text-[9px] md:text-sm opacity-80 leading-relaxed">Proses ekstrak link sangat cepat, nggak pakai lama nunggu loading.</p>
      </div>
      <div className="neo-card bg-white dark:bg-zinc-800 p-3 md:p-8 border-[3px] md:border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-1.5 md:gap-4 text-black dark:text-white">
        <div className="w-8 h-8 md:w-12 md:h-12 bg-pink-400 border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-black rounded flex items-center justify-center shrink-0">
          <Ban className="w-4 h-4 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-xs md:text-lg mt-1 md:mt-2 uppercase tracking-tight leading-tight">Tanpa Watermark</h3>
        <p className="font-bold text-[9px] md:text-sm opacity-80 leading-relaxed">Dapatkan video dengan kualitas original dan bersih dari logo aplikasi.</p>
      </div>
      <div className="neo-card bg-white dark:bg-zinc-800 p-3 md:p-8 border-[3px] md:border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-1.5 md:gap-4 text-black dark:text-white">
        <div className="w-8 h-8 md:w-12 md:h-12 bg-cyan-400 border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-black rounded flex items-center justify-center shrink-0">
          <ShieldCheck className="w-4 h-4 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-xs md:text-lg mt-1 md:mt-2 uppercase tracking-tight leading-tight">100% Aman</h3>
        <p className="font-bold text-[9px] md:text-sm opacity-80 leading-relaxed">Nggak butuh instal aplikasi tambahan atau ekstensi browser.</p>
      </div>
      <div className="neo-card bg-white dark:bg-zinc-800 p-3 md:p-8 border-[3px] md:border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-1.5 md:gap-4 text-black dark:text-white">
        <div className="w-8 h-8 md:w-12 md:h-12 bg-yellow-400 border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-black rounded flex items-center justify-center shrink-0">
          <Smartphone className="w-4 h-4 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-xs md:text-lg mt-1 md:mt-2 uppercase tracking-tight leading-tight">Mobile Friendly</h3>
        <p className="font-bold text-[9px] md:text-sm opacity-80 leading-relaxed">Desainnya pas dan responsif banget buat kamu yang suka buka dari HP.</p>
      </div>
    </div>
  </section>

  {/* How to Use Section */}
  <section className="flex flex-col gap-6 md:gap-10 items-center">
    <div className="flex flex-col items-center">
      <h2 className="text-2xl md:text-4xl font-black tracking-tight mb-2 uppercase">Cara Menggunakan</h2>
      <div className="px-4 py-1.5 md:px-6 md:py-2 bg-yellow-400 text-black border-2 border-black font-black uppercase text-xs md:text-sm mt-2 shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
        Tiga langkah sederhana.
      </div>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full text-left mt-2 md:mt-4">
      <div className="neo-card bg-white dark:bg-zinc-800 p-6 md:p-8 border-4 border-black shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-3 md:gap-4 relative overflow-hidden text-black dark:text-white">
        <span className="absolute top-2 right-4 text-black/5 dark:text-white/5 font-black text-7xl md:text-8xl pointer-events-none">1</span>
        <span className="text-[#FF4D4D] font-mono font-black text-lg md:text-xl">01</span>
        <div className="w-12 h-12 md:w-14 md:h-14 bg-indigo-500 border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-white rounded flex items-center justify-center mb-1 md:mb-2 z-10 shrink-0">
          <AtSign className="w-5 h-5 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-base md:text-lg uppercase tracking-tight z-10 leading-tight">Copy Link Video</h3>
        <p className="font-bold text-xs md:text-sm opacity-80 leading-relaxed z-10">Cari video yang mau kamu simpan dari sosial media, lalu copy tautannya.</p>
      </div>
      <div className="neo-card bg-white dark:bg-zinc-800 p-6 md:p-8 border-4 border-black shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-3 md:gap-4 relative overflow-hidden text-black dark:text-white">
        <span className="absolute top-2 right-4 text-black/5 dark:text-white/5 font-black text-7xl md:text-8xl pointer-events-none">2</span>
        <span className="text-yellow-500 font-mono font-black text-lg md:text-xl">02</span>
        <div className="w-12 h-12 md:w-14 md:h-14 bg-[#00FF94] border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-black rounded flex items-center justify-center mb-1 md:mb-2 z-10 shrink-0">
          <Loader2 className="w-5 h-5 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-base md:text-lg uppercase tracking-tight z-10 leading-tight">Paste di Sini</h3>
        <p className="font-bold text-xs md:text-sm opacity-80 leading-relaxed z-10">Tempelkan link tadi ke kolom input di bagian atas, lalu klik tombol unduh.</p>
      </div>
      <div className="neo-card bg-white dark:bg-zinc-800 p-6 md:p-8 border-4 border-black shadow-[6px_6px_0_0_rgba(0,0,0,1)] flex flex-col gap-3 md:gap-4 relative overflow-hidden text-black dark:text-white">
        <span className="absolute top-2 right-4 text-black/5 dark:text-white/5 font-black text-7xl md:text-8xl pointer-events-none">3</span>
        <span className="text-cyan-500 font-mono font-black text-lg md:text-xl">03</span>
        <div className="w-12 h-12 md:w-14 md:h-14 bg-pink-500 border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,1)] text-white rounded flex items-center justify-center mb-1 md:mb-2 z-10 shrink-0">
          <Download className="w-5 h-5 md:w-6 md:h-6" />
        </div>
        <h3 className="font-black text-base md:text-lg uppercase tracking-tight z-10 leading-tight">Download Sepuasnya</h3>
        <p className="font-bold text-xs md:text-sm opacity-80 leading-relaxed z-10">Pilih resolusi atau format yang kamu butuhkan, dan video akan tersimpan.</p>
      </div>
    </div>
  </section>

  {/* FAQ Section */}
  <section className="flex flex-col gap-6 md:gap-10 items-center">
    <h2 className="text-2xl md:text-4xl font-black tracking-tight uppercase">Tanya Jawab (FAQ)</h2>
    <div className="w-full max-w-3xl flex flex-col bg-white dark:bg-zinc-800 border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] md:shadow-[8px_8px_0_0_rgba(0,0,0,1)] text-left text-black dark:text-white">
      {[
        { q: "Apakah aplikasi ini gratis?", a: "Ya, seratus persen gratis tanpa ada batasan download sama sekali. Silakan gunakan sepuasnya." },
        { q: "Harus install aplikasi dulu nggak?", a: "Nggak perlu! Semuanya berjalan langsung dari browser kamu, baik lewat HP maupun komputer." },
        { q: "Kenapa kadang gagal saat mengunduh video?", a: "Biasanya karena video di-private oleh pembuatnya, dihapus, atau server sedang sibuk. Pastikan videonya bersifat publik ya." },
        { q: "Hasil download TikTok-nya beneran tanpa watermark?", a: "Betul, sistem kami akan mencari opsi kualitas HD tanpa watermark dari server jika memungkinkan." },
        { q: "Boleh nggak nyimpen video milik orang lain?", a: "Tentu, tapi gunakan secara bijak untuk keperluan pribadi. Jangan disalahgunakan atau melanggar hak cipta kreator ya!" }
      ].map((faq, index) => (
        <div key={index} className="border-b-4 border-black last:border-b-0 group">
          <button
            onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
            className="w-full px-4 py-4 md:px-6 md:py-5 flex items-center justify-between text-left focus:outline-none hover:bg-yellow-400 hover:text-black transition-colors"
          >
            <span className="font-black text-sm md:text-lg uppercase tracking-tight pr-4 leading-tight">{faq.q}</span>
            {openFaqIndex === index ? (
              <ChevronUp className="w-5 h-5 md:w-6 md:h-6 shrink-0" />
            ) : (
              <ChevronDown className="w-5 h-5 md:w-6 md:h-6 shrink-0" />
            )}
          </button>
          <AnimatePresence>
            {openFaqIndex === index && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden bg-white dark:bg-zinc-800 text-black dark:text-white"
              >
                <div className="px-4 pb-4 md:px-6 md:pb-6 pt-3 md:pt-4 font-bold text-xs md:text-sm opacity-90 leading-relaxed border-t-4 border-black">
                  {faq.a}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  </section>
</div>

</div>
  );
}
