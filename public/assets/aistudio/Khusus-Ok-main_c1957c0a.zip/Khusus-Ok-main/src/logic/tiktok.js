export const init = () => {
  console.log("TikTok Logic Initialized");
  
  const downloadTikTok = async (url) => {
    try {
      const response = await fetch(`https://lirenxin-api.my.id/api/download/tiktok?url=${encodeURIComponent(url)}`);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("TikTok Download Error:", error);
      return null;
    }
  };

  // Expose to window for global access if needed
  window.downloadTikTok = downloadTikTok;
};
