const fs = require('fs');
let code = fs.readFileSync('api/index_new.ts', 'utf8');

const proxies = [
  'tiktok', 'instagram', 'youtube', 'snackvideo', 'facebook', 'douyin', 'xiaohongshu', 'twitter', 'bilibili', 'kwai', 'threads'
];

for (const platform of proxies) {
  code += `\n// ${platform.charAt(0).toUpperCase() + platform.slice(1)} Proxy\napp.get("/api/proxy/${platform}", async (req, res) => {\n  const { url } = req.query;\n  if (!url) return res.status(400).json({ error: "URL is required" });\n\n  console.log(\`[${platform} Proxy] Processing URL: \${url}\`);\n  try {\n    const result = await seekin.download(url as string);\n    if (!result.formats?.length && !result.images?.length) {\n      throw new Error("No media formats or images found on Seekin.");\n    }\n    console.log(\`[${platform} Proxy] Seekin downloader success: \${result.title}\`);\n`;

  if (platform === 'youtube') {
    code += `
    let mainDownload = result.formats.find((f: any) => f.url && f.url.includes("itag=22"))?.url;
    if (!mainDownload) mainDownload = result.formats.find((f: any) => f.url && f.url.includes("itag=18"))?.url;
    if (!mainDownload) {
      const videoOnlyItags = ["itag=137", "itag=136", "itag=135", "itag=160", "itag=299", "itag=298", "itag=399", "itag=398", "itag=397", "itag=396", "itag=395", "itag=394"];
      mainDownload = result.formats.find((f: any) => f.ext === "mp4" && f.url && !videoOnlyItags.some((tag: string) => f.url.includes(tag)))?.url;
    }
    if (!mainDownload) mainDownload = result.formats.find((f: any) => f.ext === "mp4" || f.quality.toLowerCase().includes("video"))?.url || result.formats[0]?.url;

    return res.json({
      status: true,
      title: result.title,
      thumbnail: result.thumbnail,
      download: mainDownload,
      author: "",
      downloads: result.formats.map((f: any) => ({
        quality: formatDownloadLabel(f.quality, f.ext),
        url: f.url
      })),
      images: result.images || []
    });
`;
  } else if (platform === 'threads') {
     code += `
    return res.json({
      status: true,
      title: result.title || "Threads Post",
      thumbnail: result.thumbnail,
      video: result.formats.find((f: any) => !f.quality.toLowerCase().includes("audio"))?.url || "",
      downloads: result.formats.map((f: any) => ({
        quality: formatDownloadLabel(f.quality, f.ext),
        url: f.url
      })),
      images: result.images || []
    });
`;
  } else {
    code += `
    return res.json({
      status: true,
      title: result.title,
      thumbnail: result.thumbnail,
      video: result.formats.find((f: any) => f.ext === "mp4" || f.quality.toLowerCase().includes("video"))?.url || result.formats[0]?.url,
      audio: result.formats.find((f: any) => f.quality.toLowerCase().includes("audio") || f.ext === "mp3")?.url || "",
      music: result.formats.find((f: any) => f.quality.toLowerCase().includes("audio") || f.ext === "mp3")?.url || "",
      mp3: result.formats.find((f: any) => f.quality.toLowerCase().includes("audio") || f.ext === "mp3")?.url || "",
      downloads: result.formats.map((f: any) => ({
        quality: formatDownloadLabel(f.quality, f.ext),
        url: f.url
      })),
      images: result.images || []
    });
`;
  }

  code += `  } catch (error: any) {\n    console.error(\`[${platform} Proxy] Seekin failed:\`, error.message);\n    return res.status(500).json({ error: "Gagal menemukan data dari server Seekin. Pastikan URL benar, postingan bersifat publik, dan coba beberapa saat lagi!" });\n  }\n});\n`;
}

code += `
// Catch-all route to return JSON instead of HTML for unhandled API requests
app.use((req, res, next) => {
  if (req.path.startsWith("/api")) {
    res.status(404).json({
      error: \`Rute API tidak ditemukan: \${req.method} \${req.path}\`
    });
  } else {
    next();
  }
});

export default app;
`;

fs.writeFileSync('api/index_new.ts', code);
