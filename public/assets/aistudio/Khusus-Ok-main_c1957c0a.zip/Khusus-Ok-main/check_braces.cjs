const fs = require('fs');
const content = fs.readFileSync('api/index.ts', 'utf-8');
let openCount = 0;
for (let i = 0; i < content.length; i++) {
  if (content[i] === '{') openCount++;
  else if (content[i] === '}') openCount--;
}
console.log('Brace count difference:', openCount);
