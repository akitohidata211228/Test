const fs = require('fs');
const content = fs.readFileSync('api/index.ts', 'utf-8');
const lines = content.split('\n');

let openCount = 0;
let newLines = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  // If we are about to start a new app.get or app.use, ensure openCount is 0
  if (line.match(/^app\.(get|use)\(/) || line.match(/^\/\/ [A-Z].+ Proxy/)) {
    while (openCount > 0) {
      if (openCount === 1) {
        newLines.push('});'); // Close app.get
      } else {
        newLines.push('}');
      }
      openCount--;
    }
  }

  newLines.push(line);

  // update openCount
  // simple brace counting for this line
  for (let char of line) {
    if (char === '{') openCount++;
    if (char === '}') openCount--;
  }
}

while (openCount > 0) {
  if (openCount === 1) newLines.push('});');
  else newLines.push('}');
  openCount--;
}

fs.writeFileSync('api/index.ts', newLines.join('\n'));
