const fs = require('fs');
let code = fs.readFileSync('api/index.ts', 'utf-8');

const igCode = `
// Instagram Proxy
app.get("/api/proxy/instagram", async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: "URL is required" });
  
  // Debug Fallback for instagram
  return res.json({
    status: true,
    title: "Instagram Post (Debug Fallback)",
    thumbnail: "https://www.instagram.com/static/images/ico/favicon.ico/36b3ee2d91ed.ico",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    audio: "",
    music: "",
    mp3: "",
    downloads: [{ quality: "Debug Video", url: "https://www.w3schools.com/html/mov_bbb.mp4" }],
    images: [],
    isFallback: true
  });
});
`;

code = code.replace('// Threads Proxy', igCode + '\n// Threads Proxy');
fs.writeFileSync('api/index.ts', code);
