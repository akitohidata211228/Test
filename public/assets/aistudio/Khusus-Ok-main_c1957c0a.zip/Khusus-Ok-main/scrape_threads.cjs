const axios = require('axios');
async function scrape(url) {
    try {
        const post_id = url.split('/post/')[1].split('/')[0].split('?')[0];
        console.log("Post ID:", post_id);
        const res = await axios.post('https://www.threads.net/api/graphql', 
            `av=0&__user=0&__a=1&__req=1&__hs=19612.HYP%3Abarcelona_web_pkg.2.1..0.0&dpr=1&__ccg=UNKNOWN&__rev=1008740523&__s=i2jsw1%3Az57mwe%3Az56w1q&__hsi=7278235288599426370&__dyn=7xeUjG1mxu1syUbFp41twpUnwgU7Sbzo5-0B-q1ew65xO0yE1kEo2owxW0nC2i1ywa-0D82Uw8O0n24oaEd82zW0pW0nC1aU1SExS11wdq0HwEwk9q0Cg0k90QO1Fw5vwea&__csr=g31E3S998M00010041w&__comet_req=29&lsd=Zt9q-eApeD4W3nF0mHnL0v&jazoest=21868&__spin_r=1008740523&__spin_b=trunk&__spin_t=1694621035&__jssesw=1&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=BarcelonaPostPageQuery&variables=%7B%22postID%22%3A%22${post_id}%22%7D&server_timestamps=true&doc_id=6625477017551065`,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-IG-App-ID': '238260118697367',
                    'X-FB-LSD': 'Zt9q-eApeD4W3nF0mHnL0v',
                    'Sec-Fetch-Site': 'same-origin',
                }
            }
        );
        console.log("Response:", res.data);
    } catch(e) {
        console.error(e.message);
    }
}
scrape("https://www.threads.net/@instagram/post/CxJv9h1oJ9e");
