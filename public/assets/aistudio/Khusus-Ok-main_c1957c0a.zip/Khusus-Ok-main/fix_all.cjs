const fs = require('fs');
let code = fs.readFileSync('api/index.ts', 'utf-8');

const targetStr = '// TikTok Proxy using new API (iyayn)';
const idx = code.indexOf(targetStr);

if (idx > -1) {
  let before = code.substring(0, idx);
  
  const endCode = `
const platforms = [
  "tiktok", "instagram", "youtube", "snackvideo", "facebook", 
  "douyin", "xiaohongshu", "twitter", "bilibili", "kwai", "threads"
];

platforms.forEach(platform => {
  app.get(\`/api/proxy/\${platform}\`, async (req: any, res: any) => {
    const { url } = req.query;
    if (!url) return res.status(400).json({ error: "URL is required" });
    
    try {
       console.log(\`[\${platform} Proxy] Processing URL: \${url}\`);
       
       // specific fallback scrapers
       if (platform === 'tiktok') {
           const tk = await scrapeTikTok(url as string);
           if (tk) {
             return res.json({
               status: true,
               ...tk
             });
           }
       }
       if (platform === 'instagram') {
           const ig = await scrapeInstagram(url as string);
           if (ig) {
             return res.json({
               status: true,
               ...ig
             });
           }
       }
       if (platform === 'threads') {
           const th = await scrapeThreads(url as string);
           if (th) {
             return res.json({
               status: true,
               ...th
             });
           }
       }
       
       // Try seekin
       const result = await seekin.download(url as string);
       let mainDownload = result.formats.find((f: any) => f.ext === "mp4" || f.quality.toLowerCase().includes("video"))?.url || result.formats[0]?.url;
       let finalAudio = result.formats.find((f: any) => f.quality.toLowerCase().includes("audio") || f.ext === "mp3")?.url || "";
       
       return res.json({
           status: true,
           title: result.title || \`\${platform} media\`,
           thumbnail: result.thumbnail || "",
           video: mainDownload || "",
           audio: finalAudio,
           music: finalAudio,
           mp3: finalAudio,
           downloads: result.formats,
           images: result.images.map((i: any) => i.url)
       });
       
    } catch (err: any) {
       console.error(\`[\${platform} Proxy] error:\`, err.message);
       return res.status(500).json({ error: \`Gagal mengunduh dari \${platform}. Pastikan link bersifat publik, valid, dan coba lagi. (\${err.message})\` });
    }
  });
});

// Catch-all route to return JSON instead of HTML for unhandled API requests
app.use((req: any, res: any, next: any) => {
  if (req.path.startsWith("/api")) {
    res.status(404).json({
      error: \`Rute API tidak ditemukan: \${req.method} \${req.path}\`
    });
  } else {
    next();
  }
});

export default app;
`;

  fs.writeFileSync('api/index.ts', before + '\n' + endCode);
}
