const fs = require('fs');
const content = fs.readFileSync('api/index.ts', 'utf-8');
const lines = content.split('\n');

let openCount = 0;
let newLines = [];

for (let i = 0; i < lines.length; i++) {
  let line = lines[i];
  
  // If we are about to start a new app.get or app.use, ensure openCount is 0
  if (line.match(/^app\.(get|use)\(/) || line.match(/^\/\/ [A-Z].+ Proxy/)) {
    while (openCount > 0) {
      if (openCount === 1) newLines.push('});');
      else newLines.push('}');
      openCount--;
    }
    openCount = 0;
  }

  // Count braces in this line
  let lineOpen = 0;
  let lineClose = 0;
  for (let char of line) {
    if (char === '{') lineOpen++;
    if (char === '}') lineClose++;
  }

  // If this line closes more than we have open, drop the extra closing braces from the line!
  if (lineClose > 0 && openCount + lineOpen - lineClose < 0) {
     // Skip this line if it's just closing braces
     if (line.trim().match(/^[}\s;]+$/)) {
        continue;
     }
  }

  newLines.push(line);
  openCount += lineOpen - lineClose;
}

while (openCount > 0) {
  if (openCount === 1) newLines.push('});');
  else newLines.push('}');
  openCount--;
}

fs.writeFileSync('api/index.ts', newLines.join('\n'));
