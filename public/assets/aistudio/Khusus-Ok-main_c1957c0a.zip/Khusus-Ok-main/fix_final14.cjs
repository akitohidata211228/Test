const fs = require('fs');
let lines = fs.readFileSync('api/index.ts', 'utf-8').split('\n');
lines.splice(1871, 1); // delete line 1872 (index 1871)
fs.writeFileSync('api/index.ts', lines.join('\n'));
