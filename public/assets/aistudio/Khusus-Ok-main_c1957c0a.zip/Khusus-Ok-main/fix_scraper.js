const fs = require('fs');
let code = fs.readFileSync('src/lib/scraper.ts', 'utf-8');
code = code.replace(/};\s*\*\s*You can implement custom scraping logic here\.\s*\*\//g, '};');
fs.writeFileSync('src/lib/scraper.ts', code);
