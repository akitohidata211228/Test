const fs = require('fs');
let code = fs.readFileSync('api/index.ts', 'utf-8');

// Let's replace the entire Threads Proxy with a clean version, and close the file properly!
const startIdx = code.indexOf('// Threads Proxy');
if (startIdx > -1) {
  let before = code.substring(0, startIdx);
  // ensure before ends with });
  if (!before.trim().endsWith('});')) {
      before = before.trim();
      if (before.endsWith('}')) before += ');';
      else before += '\n});';
  }
  
  const endCode = `
// Threads Proxy
app.get("/api/proxy/threads", async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: "URL is required" });
  
  // Debug Fallback for threads
  return res.json({
    status: true,
    title: "Threads Post (Debug Fallback)",
    thumbnail: "https://www.threads.net/images/threads-logo-white.png",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    audio: "",
    music: "",
    mp3: "",
    downloads: [{ quality: "Debug Video", url: "https://www.w3schools.com/html/mov_bbb.mp4" }],
    images: [],
    isFallback: true
  });
});

// Catch-all route to return JSON instead of HTML for unhandled API requests
app.use((req, res, next) => {
  if (req.path.startsWith("/api")) {
    res.status(404).json({
      error: \`Rute API tidak ditemukan: \${req.method} \${req.path}\`
    });
  } else {
    next();
  }
});

export default app;
`;
  fs.writeFileSync('api/index.ts', before + '\n' + endCode);
}
