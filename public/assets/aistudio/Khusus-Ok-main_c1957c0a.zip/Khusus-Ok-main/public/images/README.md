# Images directory for slider photos
