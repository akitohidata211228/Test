const fs = require('fs');
let content = fs.readFileSync('api/index.ts', 'utf-8');

// The replacement should add `});` at the end of the debug fallback.
content = content.replace(/(Debug Fallback[\s\S]*?isFallback: true\s*\}\);\s*\})/g, '$1\n});');

fs.writeFileSync('api/index.ts', content);
