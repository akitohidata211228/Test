const fs = require('fs');
let lines = fs.readFileSync('api/index.ts', 'utf-8').split('\n');
lines.splice(1875, 0, '}');
fs.writeFileSync('api/index.ts', lines.join('\n'));
