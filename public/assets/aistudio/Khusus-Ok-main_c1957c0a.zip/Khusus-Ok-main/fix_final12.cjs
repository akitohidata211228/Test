const fs = require('fs');
let lines = fs.readFileSync('api/index.ts', 'utf-8').split('\n');
// Let's remove lines 1874 and 1875 which I added
lines.splice(1874, 2);
// Let's remove line 1872 which is `  }`
lines.splice(1872, 1);
fs.writeFileSync('api/index.ts', lines.join('\n'));
