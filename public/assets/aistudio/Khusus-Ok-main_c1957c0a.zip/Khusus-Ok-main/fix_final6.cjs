const fs = require('fs');
let lines = fs.readFileSync('api/index.ts', 'utf-8').split('\n');
lines.splice(1652, 1); // Delete line 1653 (index 1652)
fs.writeFileSync('api/index.ts', lines.join('\n'));
