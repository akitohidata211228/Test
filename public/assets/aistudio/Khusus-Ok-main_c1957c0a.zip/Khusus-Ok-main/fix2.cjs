const fs = require('fs');
let content = fs.readFileSync('api/index.ts', 'utf-8');
content = content.replace(/isFallback: true\s*\}\);\s*\}\s*\}\);/g, 'isFallback: true\n    });\n  }');
fs.writeFileSync('api/index.ts', content);
