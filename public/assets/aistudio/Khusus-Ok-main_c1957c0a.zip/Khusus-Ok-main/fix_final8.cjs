const fs = require('fs');
let content = fs.readFileSync('api/index.ts', 'utf-8');
content = content.replace(/isFallback: true\n    \}\)\;\n  \}\n\}\)\;\n\n\/\/ Threads Proxy/g, 'isFallback: true\n    });\n});\n\n// Threads Proxy');
fs.writeFileSync('api/index.ts', content);
